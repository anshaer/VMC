# Blender VMC v0.2 — AI 接手

原創實作，GPL-3.0-or-later；未整合或複製 VMC Link。Extension ID anshaer_web_vmc，面板 Anshaer VMC。目標 Blender 4.2–5.2；最低4.2.0、最大5.3.0（exclusive）。不要沒有測試就移除版本上限。

接收：手機／平板 → 已有通用 VMC WebRTC 接收頁 → Go 橋接器 → UDP loopback39540 → 本插件。沒有相機、PeerJS、HTTP／WebSocket伺服器寫在插件內；不要誤說已不需要本機橋接程式。

osc.py 是 bounded stdlib parser：65507 bytes、128 messages、3層bundle、UTF-8與padding、finite float、s/f/i tags、VMC／ANSHA namespaces。parse+decode 完成才 mutation；不合法封包不改目前資料。BlendVal可跨封包pending，BlendApply才commit。

Runtime用bpy.app.timers在主執行緒讀nonblocking UDP：最多128 datagrams或6ms／tick。沒有Python背景執行緒操作bpy；不要加入無上限Queue或frame歷史。每種state至多128names；3秒清過期資料，保持上次姿態。停止關socket/unregister timer；load_pre、unregister、目標刪除也停。

骨骼位置忽略，只用旋轉；Root選擇性應用物件位置旋轉。骨骼來源Quaternion先做reference^-1*incoming，再座標與per-bone signed-axis矩陣共軛轉換，再骨骼rest-local軸共軛、起始basis與Euler補正。不要只按VRM0／1全部轉180度。Quaternion內部(w,x,y,z)，VMC wire(x,y,z,w)。Source coordinate default (X,-Z,Y)，按實際來源/rig調整。

中立校正3秒後擷取新鮮VMC值，對應開始接收時的姿態。每Bone mapping保存Quaternion參考，並非偵測Tpose。沒有新鮮資料不覆寫。

Shape Key名稱可直接map；VRM0／VRM1 metadata從已安裝VRM Add-on讀取，無hard package import。VRM0 bind.index可能是Shape Key名稱字串，VRM1是int索引，兩者都有支援；VRM1 thumb命名依metacarpal/proximal/distal對應。Read-only metadata adapter不改VRM元資料。材料/貼圖bind不支援，同target多別名用max，不是全表情加總。

Record current frame使用PoseBone.keyframe_insert、ShapeKey.keyframe_insert，不直接操作Action.fcurves，避免4.4 Action API變動；本版沒有連續錄製。

測試：真實bpy 4.2.23/4.5.3/5.2.2，Socket UDP與Go HTTP橋接通路；普通骨架/Shape Keyfixture和VRM metadata結構fixture。沒有Window GUI／用戶角色視覺測試。直接import測試模組在embedded bpy4.2退出前須unregister並清理模組，以免standalone bpy 的 RNA shutdown lifetime 問題；不要將測試host的sys.modules清理搬進使用者插件。

UI自動映射時空白項目保留，需要手動選；Rigify含constraints的controller/deform有別，不保證全rig自動正確。映射Scene資料可隨blend存，runtime不保存，不自動開始。
